#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 
#moj_import <minecraft:sample_lightmap.glsl>

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_2199495f(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d253c670() {
    vertexColor=Color*sample_lightmap(Sampler2, UV2);
}


void f_3f4cb76a(inout vec4 vertex) {
    f_2199495f(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d253c670();
    }
        finalize();
}



void f_65857118() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*sample_lightmap(Sampler2, UV2);
}

void f_a96c22a4() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_c61dc091(inout vec4 vertex) {
    f_2199495f(vertex);
    f_65857118();
    finalize();
}

void f_2c1c6a8b(inout vec4 vertex) {
    f_2199495f(vertex);
    f_d253c670();
    f_a96c22a4();
    finalize();
}

void f_870e3f61(inout vec4 vertex) {
    f_2199495f(vertex);
    f_a96c22a4();
    f_65857118();
    finalize();
}

void f_5d1943a4(inout vec4 vertex) {
    f_d253c670();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_2199495f(vertex);
    finalize();
}

void f_872e8e42(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_65857118();
    f_2199495f(vertex);
    finalize();
}

void f_9448756f(inout vec4 vertex, float speed) {
    f_2199495f(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*sample_lightmap(Sampler2, UV2);
    finalize();
}



void f_86669424(inout vec4 vertex) {
    f_2199495f(vertex);
    f_d253c670();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*sample_lightmap(Sampler2, UV2);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_3f4cb76a(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d253c670();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_2199495f(vertex);
            f_d253c670();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_2c1c6a8b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_2c1c6a8b(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_5d1943a4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_5d1943a4(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_9448756f(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_86669424(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_c61dc091(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_2c1c6a8b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_870e3f61(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_5d1943a4(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_872e8e42(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_9448756f(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_c61dc091(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_2c1c6a8b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_870e3f61(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_5d1943a4(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_872e8e42(vertex);
        return;
    }
    

    
    f_2199495f(vertex);
    f_d253c670();
    finalize();
}